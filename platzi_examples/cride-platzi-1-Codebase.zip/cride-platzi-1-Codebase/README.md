Comparte Ride
=============

Group-bounded, invite-only, carpooling platform
