
"""Rides app."""

from django.apps import AppConfig


class RidesAppConfig(AppConfig):
    """Rides app config."""

    name = 'cride.rides'
    verbose_name = 'Rides'
